require('querybuilderpg').init('', CONF.database, 1, ERROR('DB'));
require('querybuilderpg').init('db2', CONF.database2, 1, ERROR('DB2'));

